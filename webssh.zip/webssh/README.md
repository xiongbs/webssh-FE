# 🚀 开发注意事项

npm install 

```
npm run build
```

or

```
yarn build
```


# 打包检查项

* 线上的时候开发需要使用npm run build 生成dist文件夹内容放到smartcmp-ui的webssh下
